package Agro_Technology;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import CommonFunctions.CommonFunction;

public class Details extends CommonFunction{
	
	@Test
	public void Digital_MediaDetails() {
		try {
			String URL = properties.getProperty("AdvertisementMaterialCategoryURL");
			driver.navigate().to(URL);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			
			waitTimeForException(5);
			IterateSubCatagoryAndCaptureCompanyDetails();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}
}
