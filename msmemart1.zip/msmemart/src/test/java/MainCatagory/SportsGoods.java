package MainCatagory;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import CommonFunctions.CommonFunction;

public class SportsGoods extends CommonFunction{

	@Test
	public void Details() {
		try {
			String URL = URLDataproperties.getProperty(ClassName);
			driver.navigate().to(URL);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			
			waitTimeForException(5);
			IterateSubCatagoryAndCaptureCompanyDetails();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}
	
}
