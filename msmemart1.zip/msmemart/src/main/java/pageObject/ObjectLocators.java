package pageObject;

public class ObjectLocators {
	
	//Advertisement Material
	public String AdvertisingMaterialsMenu          = "//a[contains(text(),'Advertising Materials')]";
	public String Digital_MediaMenu                 = "//a[contains(text(),'Digital Media')]";
	public String Exhibition_AdvertisingMenu        = "//a[contains(text(),'Exhibition Advertising')]";
	public String MagazinesAdvertisingMenu          = "//a[contains(text(),'Magazines Advertising')]";
	public String NewspaperAdvertisingMenu          = "//a[contains(text(),'Newspaper Advertising')]";
	public String TVAdvertisingMenu                 = "//a[contains(text(),'TV Advertising')]";
	
	//Agro Technology
	public String AgroTechnologyMainMenu            = "//ul[contains(@class,'top_category_list')]//li//a[contains(text(),'Agro Technology')]";
	public String AgricultureProductStocksMenu      = "//div[@id='home']//li//a[contains(text(),'Agriculture Product Stocks')]";
	public String AgroandAgroBasedProductsMenu      = "//div[@id='home']//li//a[contains(text(),'Agro and Agro Based Products')]";
	public String AnimalExtractMenu                 = "//div[@id='home']//li//a[contains(text(),'Animal Extract')]";
	public String AnimalFoddersMenu                 = "//div[@id='home']//li//a[contains(text(),'Animal Fodders')]";
	public String AnimalSheepCasingsMenu            = "//div[@id='home']//li//a[contains(text(),'Animal Sheep Casings')]";
	public String BakeryandConfectioneryProMenu     = "//div[@id='home']//li//a[contains(text(),'Bakery and Confectionery Pro')]";
	public String BambooandRattanProductsMenu       = "//div[@id='home']//li//a[contains(text(),'Bamboo and Rattan Products')]";
	public String BeansMenu                         = "//div[@id='home']//li//a[contains(text(),'Beans')]";
	public String CashewsMenu                       = "//div[@id='home']//li//a[contains(text(),'Cashews')]";
	public String CerealsMenu                       = "//div[@id='home']//li//a[contains(text(),'Cereals')]";
	public String CoconutShellProductsMenu          = "//div[@id='home']//li//a[contains(text(),'Coconut Shell Products')]";
	public String CoffeeMenu                        = "//div[@id='home']//li//a[contains(text(),'Coffee')]";
	public String CoirProductsMenu                  = "//div[@id='home']//li//a[contains(text(),'Coir Products')]";
	public String EggsMenu                          = "//div[@id='home']//li//a[contains(text(),'Eggs')]";
	public String FertilizerMenu                    = "//div[@id='home']//li//a[contains(text(),'Fertilizer')]";
	public String FibersMenu                        = "//div[@id='home']//li//a[contains(text(),'Fibers')]";
	public String FoodProcessingPlantsMachiMenu     = "//div[@id='home']//li//a[contains(text(),'Food Processing Plants Machi')]";
	public String FruitandVegetablesFreshMenu       = "//div[@id='home']//li//a[contains(text(),'Fruit and Vegetables Fresh P')]";
	public String GrainMenu                         = "//div[@id='home']//li//a[contains(text(),'Grain')]";
	public String GreenHouseSuppliesandEquMenu      = "//div[@id='home']//li//a[contains(text(),'Green House Supplies and Equ')]";
	public String HerbalFoodandBeveragesMenu        = "//div[@id='home']//li//a[contains(text(),'Herbal Food and Beverages')]";
	public String IrrigationEquipmentMenu           = "//div[@id='home']//li//a[contains(text(),'Irrigation Equipment')]";
	public String JuteandJuteProductsMenu           = "//div[@id='home']//li//a[contains(text(),'Jute and Jute Products')]";
	public String LiquorsMineralWaterandBeMenu       = "//div[@id='home']//li//a[contains(text(),'Liquors Mineral Water and Be')]";
	public String MarineFoodSuppliesMenu            = "//div[@id='home']//li//a[contains(text(),'Marine Food Supplies')]";
	

}
