package CommonFunctions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.InvalidSelectorException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.UnreachableBrowserException;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

@SuppressWarnings("unused")
public class CommonFunction {
	public static Properties properties=null;
	public static Properties ExcelDataproperties=null;
	public static Properties URLDataproperties=null;
	public static WebDriver driver=null;
	public static String SheetName;
	public static String ClassName;


	public Properties PropertyFile() throws IOException{
		FileInputStream fileInputStream =new FileInputStream("./src/main/resources/Configure.properties");
		properties = new Properties();
		properties.load(fileInputStream);
		return properties;
	}

	public Properties ExcelDataPropertyFile() throws IOException{
		FileInputStream fileInputStream =new FileInputStream("./src/main/resources/ExcelLocationData.properties");
		ExcelDataproperties = new Properties();
		ExcelDataproperties.load(fileInputStream);
		return ExcelDataproperties;
	}

	public Properties URLDataPropertyFile() throws IOException{
		FileInputStream fileInputStream =new FileInputStream("./src/main/resources/URLData.properties");
		URLDataproperties = new Properties();
		URLDataproperties.load(fileInputStream);
		return URLDataproperties;
	}

	@BeforeSuite
	public void OpenBrowser() throws IOException{
		ClassName = getClass().getSimpleName();
		System.out.println("Class Name: "+ClassName);
		PropertyFile();
		ExcelDataPropertyFile();
		URLDataPropertyFile();
		String browser = properties.getProperty("browser");
		String driverlocation = properties.getProperty("driverlocation");

		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", driverlocation);
			driver = new ChromeDriver();

		}else{
			System.setProperty("webdriver.gecko.driver", driverlocation);
			driver = new FirefoxDriver();
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@AfterSuite
	public void CloseBrowser(){
		driver.quit();
	}

	public boolean isElementPresent(String objectLocator) {
		try {
			driver.findElement(By.xpath(objectLocator));
			System.out.println("Element present");
			return true;
		}
		catch (NoSuchElementException e2) {
			return false;
		}
		catch (Exception e) {
			System.err.println("Exception Error '" + e.toString() + "'");
			return false;
		}
	}

	public void ClickOn(String objLocator, String ObjectName) {
		try {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.findElement(By.xpath(objLocator)).click();
			System.out.println(ObjectName+" clicked successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	public void waitTimeForException(int sec) {
		try {
			Thread.sleep(sec * 1000);
		}
		catch (Exception e) {
			System.out.println(e.toString());
		}
	}

	public void EnterValueTextFiled(String Locators, String Value, String ObjectName) {
		try {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.findElement(By.xpath(Locators)).sendKeys(Value);
			System.out.println(Value+" value entered "+ObjectName+" text field.");
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	public void SelectFromDropDownByText(String Locators, String Value, String ObjectName) {
		try {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Select sele = new Select(driver.findElement(By.xpath(Locators)));
			sele.selectByVisibleText(Value);
			System.out.println(Value+" value selected "+ObjectName+" dropdown field.");
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	public void SelectFromDropDownByValue(String Locators, String Value, String ObjectName) {
		try {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Select sele = new Select(driver.findElement(By.xpath(Locators)));
			sele.selectByValue(Value);
			System.out.println(Value+" value selected "+ObjectName+" dropdown field.");
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	public void SelectFromDropDownByIndex(String Locators, int Value, String ObjectName) {
		try {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Select sele = new Select(driver.findElement(By.xpath(Locators)));
			sele.selectByIndex(Value);
			System.out.println(Value+" value selected "+ObjectName+" dropdown field.");
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	public void ScrollIntoView(String Locators) {
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			//			js.executeScript("arguments[0].scrollIntoView();", Locators);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	public String CreateSheet(String SheetName) {
		String SetSheetName = "";
		try {
			SetSheetName = SheetName;
			System.out.println("sheet name: "+SetSheetName);
			String ExcelLocation = ExcelDataproperties.getProperty(ClassName);
			File  file = new File(ExcelLocation);
			FileInputStream excel = new FileInputStream(file);
			Workbook wb = new XSSFWorkbook(excel);
			int shcount = wb.getNumberOfSheets();
			System.out.println("sheet count: "+shcount);
			Sheet sheet;
			System.out.println("Sheet creation started");
			for(int i=0;i<shcount;i++) {
				String GetsheetName = wb.getSheetName(i);
				System.out.println(GetsheetName);
				if(GetsheetName.equals(SheetName)) {
					//					wb.removeSheetAt(i);
					//					sheet = wb.cloneSheet(0);
					//					wb.setSheetName(shcount-1, SheetName);
					System.out.println("sheet already created");
					break;
				}else if(i==shcount-1) {
					sheet = wb.cloneSheet(0);
					wb.setSheetName(shcount, SheetName);
					System.out.println("sheet Newly created");
				}
			}
			FileOutputStream output = new FileOutputStream(file);
			wb.write(output);
			wb.close();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
		return SetSheetName;
	}

	public void writeExcelCompanyDetails(String SheetName, String CompanyName, String Address, String ContactNo, String WebsiteLink) {
		try {
			String[]  parameter = {CompanyName,Address,ContactNo,WebsiteLink};
			String ExcelLocation = ExcelDataproperties.getProperty(ClassName);
			File  file = new File(ExcelLocation);
			FileInputStream excel = new FileInputStream(file);
			Workbook wb = new XSSFWorkbook(excel);
			Sheet sheet = wb.getSheet(SheetName);
			int LastRow = sheet.getPhysicalNumberOfRows();
			System.out.println("Physical row: "+LastRow);
			CellStyle cellst = wb.createCellStyle();
			cellst.setBorderBottom(BorderStyle.THIN);
			cellst.setBorderLeft(BorderStyle.THIN);
			cellst.setBorderRight(BorderStyle.THIN);
			cellst.setBorderTop(BorderStyle.THIN);
			cellst.setAlignment(HorizontalAlignment.LEFT);
			cellst.setVerticalAlignment(VerticalAlignment.CENTER);
			cellst.setWrapText(true);
			Cell cell;
			Row row = sheet.createRow(LastRow);
			for(int i=0;i<parameter.length;i++) {
				cell= row.createCell(i);
				cell.setCellValue(parameter[i]);
				cell.setCellStyle(cellst);
			}
			FileOutputStream output = new FileOutputStream(file);
			wb.write(output);
			wb.close();

		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	public String GetTextFromAttributValue(String Locators, String Attributs) {
		String GetValue = "";
		try {
			ScrollIntoView(Locators);
			GetValue = driver.findElement(By.xpath(Locators)).getAttribute(Attributs).trim();
			System.out.println("Attribut value: "+GetValue);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
		return GetValue;
	}

	public String GetText(String Locators) {
		String GetValue = "";
		try {
			ScrollIntoView(Locators);
			GetValue = driver.findElement(By.xpath(Locators)).getText().trim();
			System.out.println("Get value: "+GetValue);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
		return GetValue;
	}

	public void IterateAndCaptureCompanyDetails() {
		try {
			waitTimeForException(5);
			if(isElementPresent("//ul[contains(@class ,'pagination pagination_c')]//li")) {
				// Find total number page is available
				List<WebElement> ToTalPagenationlist = driver.findElements(By.xpath("//ul[contains(@class ,'pagination pagination_c')]//li"));
				int totalpagenationlistsize = ToTalPagenationlist.size();
				String GetTotalPage = GetTextFromAttributValue("//ul[contains(@class ,'pagination pagination_c')]//li["+totalpagenationlistsize+"]//a", "data-ci-pagination-page");
				System.out.println("Tatal page: "+GetTotalPage);
				int TotalPage = Integer.valueOf(GetTotalPage);
				for(int i=0;i<TotalPage;i++) {
					ScrollIntoView("//ul[contains(@class ,'pagination pagination_c')]//li["+(i+1)+"]//a");
					ClickOn("//ul[contains(@class ,'pagination pagination_c')]//li//a[contains(text(),'"+(i+1)+"')]", (i+1)+" pagenation clicked");
					waitTimeForException(10);

					// Find company details
					List<WebElement> ToTallist = driver.findElements(By.xpath("//ul[contains(@class,'upl_list')]//li"));
					System.out.println("Company list size: "+ToTallist.size());
					for(int j=0;j<ToTallist.size();j++) {
						ScrollIntoView("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::h4//a");
						String GetCompanyName = GetText("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::h4//a");
						ScrollIntoView("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[3]");
						String GetAddress     = GetText("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[3]");
						ScrollIntoView("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[4]");
						String GetContactNo   = GetText("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[4]");
						String GetURL = "";
						ScrollIntoView("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[5]");
						if (isElementPresent("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[5]")) {
							GetURL = GetText("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[5]");
						} else {
							System.out.println(GetCompanyName+" compnay don't have website URL.");
						}
						writeExcelCompanyDetails(SheetName.toLowerCase(), GetCompanyName, GetAddress, GetContactNo, GetURL);
					}
				}
			}else {
				// Find company details
				List<WebElement> ToTallist = driver.findElements(By.xpath("//ul[contains(@class,'upl_list')]//li"));
				System.out.println("Company list size: "+ToTallist.size());
				for(int j=0;j<ToTallist.size();j++) {
					ScrollIntoView("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::h4//a");
					String GetCompanyName = GetText("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::h4//a");
					ScrollIntoView("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[3]");
					String GetAddress     = GetText("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[3]");
					ScrollIntoView("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[4]");
					String GetContactNo   = GetText("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[4]");
					String GetURL = "";
					ScrollIntoView("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[5]");
					if (isElementPresent("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[5]")) {
						GetURL = GetText("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[5]");
					} else {
						System.out.println(GetCompanyName+" compnay don't have website URL.");
					}
					writeExcelCompanyDetails(SheetName.toLowerCase(), GetCompanyName, GetAddress, GetContactNo, GetURL);
				}
			}


		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}


	public void IterateSubCatagoryAndCaptureCompanyDetails() {
		try {
			waitTimeForException(5);
			// Find total number Sub category is available
			if(isElementPresent("//div[@id='home']//li//a[contains(@class,'sub_cat_item_text')]")) {
				List<WebElement> ToTalsubcatagorylist = driver.findElements(By.xpath("//div[@id='home']//li//a[contains(@class,'sub_cat_item_text')]"));
				for(int k=0;k<ToTalsubcatagorylist.size();k++) {
					String GetSubCatagory = GetText("//div[@id='home']//li["+(k+1)+"]//a[contains(@class,'sub_cat_item_text')]");
					SheetName = CreateSheet(GetSubCatagory.toLowerCase());
					ClickOn("//div[@id='home']//li["+(k+1)+"]//a[contains(@class,'sub_cat_item_text')]", GetSubCatagory);
					waitTimeForException(5);
					if(isElementPresent("//ul[contains(@class ,'pagination pagination_c')]//li")) {
						// Find total number page is available
						List<WebElement> ToTalPagenationlist = driver.findElements(By.xpath("//ul[contains(@class ,'pagination pagination_c')]//li"));
						int totalpagenationlistsize = ToTalPagenationlist.size();
						String GetTotalPage = GetTextFromAttributValue("//ul[contains(@class ,'pagination pagination_c')]//li["+totalpagenationlistsize+"]//a", "data-ci-pagination-page");
						System.out.println("Tatal page: "+GetTotalPage);
						int TotalPage = Integer.valueOf(GetTotalPage);
						for(int i=0;i<TotalPage;i++) {
							waitTimeForException(3);
							ScrollIntoView("//ul[contains(@class ,'pagination pagination_c')]//li//a[contains(text(),'"+(i+1)+"')]");
							waitTimeForException(3);
							if(isElementPresent("//ul[contains(@class ,'pagination pagination_c')]//li//a[contains(text(),'"+(i+1)+"')]")) {
							ClickOn("//ul[contains(@class ,'pagination pagination_c')]//li//a[contains(text(),'"+(i+1)+"')]", (i+1)+" pagenation clicked");
							waitTimeForException(3);

							// Find company details
							List<WebElement> ToTallist = driver.findElements(By.xpath("//ul[contains(@class,'upl_list')]//li"));
							System.out.println("Company list size: "+ToTallist.size());
							for(int j=0;j<ToTallist.size();j++) {
								ScrollIntoView("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::h4//a");
								String GetCompanyName = GetText("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::h4//a");
								ScrollIntoView("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[3]");
								String GetAddress     = GetText("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[3]");
								ScrollIntoView("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[4]");
								String GetContactNo   = GetText("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[4]");
								String GetURL = "";
								ScrollIntoView("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[5]");
								if (isElementPresent("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[5]")) {
									GetURL = GetText("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[5]");
								} else {
									System.out.println(GetCompanyName+" compnay don't have website URL.");
								}
								writeExcelCompanyDetails(SheetName.toLowerCase(), GetCompanyName, GetAddress, GetContactNo, GetURL);
							}
							}else {
								break;
							}
						}
						driver.navigate().back();
					}else {
						// Find company details
						List<WebElement> ToTallist = driver.findElements(By.xpath("//ul[contains(@class,'upl_list')]//li"));
						System.out.println("Company list size: "+ToTallist.size());
						for(int j=0;j<ToTallist.size();j++) {
							ScrollIntoView("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::h4//a");
							String GetCompanyName = GetText("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::h4//a");
							ScrollIntoView("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[3]");
							String GetAddress     = GetText("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[3]");
							ScrollIntoView("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[4]");
							String GetContactNo   = GetText("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[4]");
							String GetURL = "";
							ScrollIntoView("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[5]");
							if (isElementPresent("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[5]")) {
								GetURL = GetText("//ul[contains(@class,'upl_list')]//li["+(j+1)+"]//following-sibling::p[5]");
							} else {
								System.out.println(GetCompanyName+" compnay don't have website URL.");
							}
							writeExcelCompanyDetails(SheetName.toLowerCase(), GetCompanyName, GetAddress, GetContactNo, GetURL);
						}
						driver.navigate().back();
					}

				}
			}else {
				System.out.println("No records found in sub catagory list");
			}


		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

}
