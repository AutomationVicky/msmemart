package Advertisement_Material_Category;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import CommonFunctions.CommonFunction;
import pageObject.ObjectLocators;

public class Digital_Media extends CommonFunction{

	@Test
	public void Digital_MediaDetails() {
		try {
			ObjectLocators objloc = new ObjectLocators();
			
			String URL = properties.getProperty("AdvertisementMaterialCategoryURL");
			driver.get(URL);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			
			ClickOn(objloc.Digital_MediaMenu, "Digital Media");
			waitTimeForException(5);
			IterateAndCaptureCompanyDetails();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}
}
